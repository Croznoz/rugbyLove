# Riprendere il progetto da Work

Questo archivio contiene il gioco completo aggiornato e modificabile.

Richiesta da accompagnare allo ZIP:

«Estrai rugbyLove.zip, leggi README.md, avvia il gioco con un server HTTP e aprilo nell’anteprima browser disponibile. I sorgenti sono in dist/ e non richiedono build né installazioni per giocare. Non pubblicare il sito: voglio prima giocare e verificare questa versione.»

Avvio locale: `npm start` dalla cartella rugbyLove; il server ascolta su http://localhost:8080.
Alternativa: `python3 -m http.server 8080 --bind 127.0.0.1 --directory dist`.
L’accesso all’anteprima dipende dall’ambiente in cui viene aperto l’archivio; lo ZIP da solo non è un sito pubblicato. Non aprire index.html con file://, perché usa moduli JavaScript.

## Novità incluse
- Calcio d’inizio conteso a inizio tempo e dopo ogni meta, conclusa la conversione.
- Uscita dalla mischia con passaggio visibile al compagno sul lato scelto, senza riposizionare le squadre.
- Indicatore del ricevitore scelto in mischia.
- Schivata: direzione laterale + SFONDA. Direzione avanti: sfondamento.
- Difesa: tocco e rilascio per tuffarsi; pressione lunga per contenere e mantenere la copertura.
- Più tempo alla ricezione, preparazione visibile dei contrasti e sostegno ravvicinato.

Verifiche dell’ultima versione: 95 test del motore e 24 test DOM dei comandi superati; controlli grafici desktop, mobile e landscape riusciti. Non equivalgono a una prova su telefono reale.

Il manifest .openai/hosting.json identifica il sito originale, non una pubblicazione di questo aggiornamento.
